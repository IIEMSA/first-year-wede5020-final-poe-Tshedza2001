
// Function to clear initial input field value
function clearInitialValue(inputField) {
  if (inputField.value === inputField.defaultValue) {
    inputField.value = '';
  }
}

// Function to validate the form
function validateForm() {
  var emailField = document.getElementById('email');
  var firstNameField = document.getElementById('firstName');
  var lastNameField = document.getElementById('lastName');

  // Check if first name is empty
  if (firstNameField.value === '') {
    alert("Please enter your first name.");
    return false;
  }

  // Check if last name is empty
  if (lastNameField.value === '') {
    alert("Please enter your last name.");
    return false;
  }

  // Check if email is empty
  if (emailField.value === '') {
    alert("Please enter your email address.");
    return false;
  }

  // Check if email has a valid format
  if (!/\S+@\S+\.\S+/.test(emailField.value)) {
    alert("Please enter a valid email address.");
    return false;
  }

  return true;
}

// Function to validate the form (refactored)

// Event listener for form submission
function validateForm() {
  const firstNameInput = document.getElementById('firstName');
  const lastNameInput = document.getElementById('lastName');
  const emailInput = document.getElementById('email');

  // Clear any previous error messages
  clearErrors();

  let isValid = true;

  // Check if first name is empty
  if (firstNameInput.value.trim() === '') {
    displayError(firstNameInput, 'First name is required');
    isValid = false;
  }

  // Check if last name is empty
  if (lastNameInput.value.trim() === '') {
    displayError(lastNameInput, 'Last name is required');
    isValid = false;
  }

  // Check if email is empty or has an invalid format
  if (emailInput.value.trim() === '') {
    displayError(emailInput, 'Email is required');
    isValid = false;
  } else if (!isValidEmail(emailInput.value)) {
    displayError(emailInput, 'Invalid email format');
    isValid = false;
  }

  return isValid;
}

// Function to display an error message for an input element
function displayError(inputElement, errorMessage) {
  const errorElement = document.createElement('span');
  errorElement.className = 'error';
  errorElement.innerText = errorMessage;

  inputElement.parentNode.appendChild(errorElement);
}

// Function to clear all error messages
function clearErrors() {
  const errorElements = document.getElementsByClassName('error');
  while (errorElements.length > 0) {
    errorElements[0].parentNode.removeChild(errorElements[0]);
  }
}

// Function to check if an email has a valid format
function isValidEmail(email) {
  const emailRegex = /^\S+@\S+\.\S+$/; // Simple email validation using a regular expression
  return emailRegex.test(email);
}

// Event listener for scrolling
window.addEventListener("scroll",   function() {
  showScrollUpButton();
});

// Function to show/hide the scroll-up button based on scroll position
function showScrollUpButton() {
var scrollUpBtn = document.getElementById("scrollUpBtn");
if (document.documentElement.scrollTop > window.innerHeight / 2) {
  scrollUpBtn.style.display = "block";
} else {
  scrollUpBtn.style.display = "none";
}
}

// Function to scroll to the top of the page
function scrollToTop() {
window.scrollTo({
  top: 0,
  behavior: "smooth"
});
}

